# Medical Store Stock Alert System — Spring Boot + Maven + MySQL

This version connects the existing stock-alert frontend to a real MySQL database through a Spring Boot REST API. The old `Main.java` in-memory server is replaced by Spring Boot.

## Requirements
- Java JDK 17 or newer
- Apache Maven 3.9+ (or use IntelliJ IDEA's Maven support)
- MySQL Server 8.x and MySQL Workbench (optional GUI)

## 1. Create the database
Open MySQL Workbench and connect to your local server, then run:

```sql
CREATE DATABASE IF NOT EXISTS medical_store;
```

The app also has `createDatabaseIfNotExist=true`; create the database manually if your MySQL account does not have permission to create databases.

## 2. Set your MySQL password
Open `src/main/resources/application.properties`. Replace `change_this_password` with your actual MySQL root password. Do not upload real passwords to GitHub.

Alternatively, set environment variables before running:
- Windows CMD: `set DB_USERNAME=root` then `set DB_PASSWORD=your_password`
- PowerShell: `$env:DB_USERNAME="root"` and `$env:DB_PASSWORD="your_password"`

If using environment variables, you can leave the fallback password in the properties file as a dummy value.

## 3. Run the app
Open CMD/Terminal in the folder containing `pom.xml` and run:

```bash
mvn spring-boot:run
```

Wait until the console says Spring Boot has started. Then open **http://localhost:8080** in your browser. Do not double-click `index.html`; open it through the Spring Boot URL so API requests use the same origin.

To build a runnable jar:

```bash
mvn clean package
java -jar target/medical-store-1.0.0.jar
```

## 4. Try it
1. Add a medicine with its name, manufacturing date, expiry date, quantity and price.
2. It should appear in the inventory.
3. Refresh the page. It should still be present because it is stored in MySQL.
4. Sell a medicine by entering the exact name and quantity. The database quantity will decrease.
5. Use Edit or Delete to test the other operations.
6. Optional API check: open `http://localhost:8080/api/medicines` to see the saved records as JSON.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/medicines` | List all medicines |
| POST | `/api/medicines` | Add medicine |
| PUT | `/api/medicines/{id}` | Edit medicine |
| POST | `/api/medicines/sale` | Sell and reduce quantity |
| DELETE | `/api/medicines/{id}` | Delete medicine |

## Folder layout
```text
MedicalStore-SpringBoot/
├── pom.xml
├── README.md
└── src/
    └── main/
        ├── java/com/medicalstore/
        │   ├── MedicalStoreApplication.java
        │   ├── Medicine.java
        │   ├── MedicineRepository.java
        │   └── MedicineController.java
        └── resources/
            ├── application.properties
            └── static/index.html
```

## Common problems
- **Access denied for user**: check MySQL username/password in `application.properties`.
- **Communications link failure / connection refused**: make sure MySQL Server is running.
- **Port 8080 already in use**: close the other app using 8080 or change `server.port` in properties.
- **`mvn` is not recognized**: install Maven and add its `bin` folder to PATH, or run from IntelliJ IDEA's Maven panel.
- **Java version errors**: check `java -version`; install/configure JDK 17+.
- **Medicine name already exists**: names are unique in this starter project; edit the existing record instead.

## Important
This is a learning/project starter. It has no login/authentication yet, so only run it locally until you add security before deploying it publicly.
