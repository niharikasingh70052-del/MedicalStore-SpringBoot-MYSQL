package com.medicalstore;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/medicines")
public class MedicineController {
    private final MedicineRepository repository;
    public MedicineController(MedicineRepository repository) { this.repository = repository; }

    public record MedicineRequest(
        @NotBlank @Size(max=150) String name,
        @NotNull LocalDate mfgDate,
        @NotNull LocalDate expDate,
        @Min(0) int qty,
        @NotNull @DecimalMin("0.00") BigDecimal price) {}
    public record SaleRequest(@NotBlank String name, @Min(1) int qty) {}
    public record MessageResponse(String message) {}

    @GetMapping
    public List<Medicine> all() { return repository.findAll(); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Medicine add(@Valid @RequestBody MedicineRequest request) {
        if (request.expDate().isBefore(request.mfgDate()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Expiry date cannot be before manufacturing date.");
        if (repository.existsByNameIgnoreCase(request.name().trim()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "A medicine with this name already exists.");
        Medicine medicine = new Medicine(request.name().trim(), request.mfgDate(), request.expDate(),
                                         request.qty(), request.price());
        return repository.save(medicine);
    }

    @PutMapping("/{id}")
    public Medicine update(@PathVariable Long id, @Valid @RequestBody MedicineRequest request) {
        Medicine medicine = repository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Medicine not found."));
        if (request.expDate().isBefore(request.mfgDate()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Expiry date cannot be before manufacturing date.");
        repository.findByNameIgnoreCase(request.name().trim()).ifPresent(existing -> {
            if (!existing.getId().equals(id))
                throw new ResponseStatusException(HttpStatus.CONFLICT, "Another medicine already uses this name.");
        });
        medicine.setName(request.name().trim()); medicine.setMfgDate(request.mfgDate());
        medicine.setExpDate(request.expDate()); medicine.setQty(request.qty()); medicine.setPrice(request.price());
        return repository.save(medicine);
    }

    @PostMapping("/sale")
    public Medicine sale(@Valid @RequestBody SaleRequest request) {
        Medicine medicine = repository.findByNameIgnoreCase(request.name().trim())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Medicine not found."));
        if (request.qty() < 1) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Sale quantity must be at least 1.");
        if (medicine.getQty() < request.qty())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough stock. Available: " + medicine.getQty());
        medicine.setQty(medicine.getQty() - request.qty());
        return repository.save(medicine);
    }

    @DeleteMapping("/{id}")
    public MessageResponse delete(@PathVariable Long id) {
        Medicine medicine = repository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Medicine not found."));
        repository.delete(medicine);
        return new MessageResponse("Medicine deleted.");
    }
}
