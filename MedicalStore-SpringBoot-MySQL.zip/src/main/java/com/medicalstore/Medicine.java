package com.medicalstore;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "medicines")
public class Medicine {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 150)
    private String name;
    @Column(name = "manufacturing_date", nullable = false)
    private LocalDate mfgDate;
    @Column(name = "expiry_date", nullable = false)
    private LocalDate expDate;
    @Column(nullable = false)
    private int qty;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    public Medicine() {}
    public Medicine(String name, LocalDate mfgDate, LocalDate expDate, int qty, BigDecimal price) {
        this.name=name; this.mfgDate=mfgDate; this.expDate=expDate; this.qty=qty; this.price=price;
    }
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getName(){return name;} public void setName(String name){this.name=name;}
    public LocalDate getMfgDate(){return mfgDate;} public void setMfgDate(LocalDate mfgDate){this.mfgDate=mfgDate;}
    public LocalDate getExpDate(){return expDate;} public void setExpDate(LocalDate expDate){this.expDate=expDate;}
    public int getQty(){return qty;} public void setQty(int qty){this.qty=qty;}
    public BigDecimal getPrice(){return price;} public void setPrice(BigDecimal price){this.price=price;}
    public String getStatus() {
        if (qty == 0) return "OUT OF STOCK";
        if (qty <= 5) return "LOW STOCK";
        return "IN STOCK";
    }
}
